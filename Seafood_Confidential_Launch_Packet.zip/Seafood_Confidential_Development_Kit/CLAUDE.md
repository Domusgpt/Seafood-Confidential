# Seafood Confidential Claude handoff

Read and follow AGENTS.md in this folder. It is the authoritative shared development instruction file. Then read docs/PRODUCT_SPEC.md, decisions/ADR-001-managed-publishing.md, docs/SPRINT_PLAN.md and docs/ACCEPTANCE_TESTS.md.

Begin with the earliest incomplete dependency in planning/BACKLOG.json. All tickets are initially planned. No application exists or has passed tests as part of this kit. Maintain docs/IMPLEMENTATION_STATUS.md as work proceeds. Do not duplicate or silently diverge from AGENTS.md.
